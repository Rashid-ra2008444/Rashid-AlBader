import kotlinx.serialization.Serializable


@Serializable
data class PublishedDate
    (val date: String)
