class Bank (
    val code : String,
    val address : String,
    ){


    fun manages() {
        println("the bank manages customers")
    }

    fun maintain(){
    println("the bank maintains the following customers")
    }
}