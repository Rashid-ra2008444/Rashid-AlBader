class SavingAccount(
    accountNo :Int,
    balance: Double
    ){}