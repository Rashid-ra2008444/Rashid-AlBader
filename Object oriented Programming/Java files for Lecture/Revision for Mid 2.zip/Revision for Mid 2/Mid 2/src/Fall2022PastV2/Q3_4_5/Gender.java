package Fall2022PastV2.Q3_4_5;

public enum Gender {
    Male,
    Female
}
