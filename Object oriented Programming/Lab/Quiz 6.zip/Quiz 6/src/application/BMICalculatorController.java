package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class BMICalculatorController {

    @FXML
    private Button button;

    @FXML
    private CheckBox cb1;

    @FXML
    private Label label1;

    @FXML
    private Label label2;

    @FXML
    private Label label3;

    @FXML
    private RadioButton rb1;
    

    @FXML
    private RadioButton rb2;
    

    @FXML
    private TextField tf1;

    @FXML
    private TextField tf2;

    @FXML
    void CalculateBMI(ActionEvent event) {
		double weight = Double.parseDouble(tf1.getText());
		double height = Double.parseDouble(tf2.getText());
		if(cb1.isSelected()) {
			weight-= weight*0.05;
		}
		double bmiValue = 0;
		if (rb1.isSelected()) {
			bmiValue = BMICalculator.calculateMetricBMI(weight, height);
		} else if (rb2.isSelected()) {
			bmiValue = BMICalculator.calculateEnglishBMI(weight, height);
		}
		label3.setText(String.format("Calculated BMI: %.2f", bmiValue));
    }
    
    @FXML
	void selectedRadioButton(ActionEvent event) {
		if (rb1.isSelected()) {
			label1.setText("Weight (KG):");
			label2.setText("Height (M):");
			rb2.setSelected(false);
		} else if (rb2.isSelected()) {
			label1.setText("Weight (Pounds):");
			label2.setText("Height (Inches):");
			rb1.setSelected(false);
		}
	}

}
