package application;

public class BMICalculator {
	public static double calculateMetricBMI(double weightInKilograms,double heightInMeters) {

		return weightInKilograms / (heightInMeters * heightInMeters);

	}

	public static double calculateEnglishBMI(double weightInPounds,double heightInInches) {

		return (weightInPounds / (heightInInches * heightInInches)) * 703;

	}

}
