package P4;

public class GradeBookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
