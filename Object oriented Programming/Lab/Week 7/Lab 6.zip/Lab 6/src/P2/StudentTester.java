package P2;

public class StudentTester {

	public static void main(String[] args) {
		Student students[] = new Student[5];
		students[0] = new Student("Ahmed");
		students[1] = new Student("Ali");
		students[2] = new Student("Mohamed");
		students[3] = new Student("Abdulla");
		students[4] = new Student("Mahmoud");

	}

}
