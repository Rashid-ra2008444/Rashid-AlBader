package quiz5;
import java.io.Serializable;
import java.time.LocalDate;
public class Product implements Serializable{
	String code;
	String category;
	int quantity;
	double unitPrice;
	LocalDate expiredDate;
	public Product() {	}
	public Product(String code, String category, int quantity, double unitPrice, LocalDate expiredDate) {
		this.code = code;
		this.category = category;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
		this.expiredDate = expiredDate;
	}
}

