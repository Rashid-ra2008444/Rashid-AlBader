package quiz5;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Quiz5 {
	Scanner in;
	ObjectOutputStream out;
	public Quiz5() {
		try {
			in = new Scanner(new File("products.txt"));
			out = new ObjectOutputStream(new FileOutputStream("products.dat"));
			String line, code, category;
			double unitPrice;
			int quantity;
			LocalDate expireDate;
			double loss = 0;
			while(in.hasNext()) {
				line = in.nextLine();
				String[] tokens = line.split(",");
				LocalDate expiredDate = LocalDate.parse(tokens[4], DateTimeFormatter.ofPattern("d/M/yyyy"));
				if(expiredDate.isAfter(LocalDate.now())) {
					code = tokens[0]; category = tokens[1];
					quantity = Integer.parseInt(tokens[2]);
					unitPrice = Double.parseDouble(tokens[3]);
					Product product = new Product(code,category,quantity,unitPrice,expiredDate);
					out.writeObject(product);
					loss += unitPrice*quantity;
				}
			}
			in.close();
			out.writeObject(null);
			out.close();
			System.out.println("Total loss = "+ loss);
		} catch (IOException e) {		}
	}

	public static void main(String[] args) {
		new Quiz5();
	}
}
