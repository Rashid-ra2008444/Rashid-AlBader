package Payments;

public interface Payment {

    double calcPaymentAmount();
}
