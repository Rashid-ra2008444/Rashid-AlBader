package Shipments;

public enum ShippingWays {
    GroundShipping,SeaFreight,AirFreight
}
